bib: files of the documents cited in the report, including the pro key (document made by the authors of the original study explaining the meaning of each variable), the original study (which studied a different question but used the same dataset), and three papers or chapter on Preprocessing and clustering. The citations were only avalaible for two of the documents, and they haven been included as well.

report:  Report in pdf and font files in tex (tex subdirectory)

data: in the corresponding subdirectories, the original dataset (Speed.csv) and the cleaned one (SpeedClean.csv)

src: R sources used, based on the ones developed by Karina Gibert.

presentation: the final presentation in both PDF and PPT formats.